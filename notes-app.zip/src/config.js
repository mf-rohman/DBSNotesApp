export const CONFIG = {
  API_BASE_URL: process.env.API_BASE_URL ?? "https://notes-api.dicoding.dev/v2",
};
