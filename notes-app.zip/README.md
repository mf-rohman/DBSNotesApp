# My Notes App 2.0
This app for submission for **Course Web Dev Fundamental** 

## Fitur
- Add New Notes
- Edit Notes in Archived or Unarchived notes (but there is still have a bug)
- Delete Notes
- Archived and UnArchived Notes

## UI
- There is Tooltip when hover title and desc of notes
- There is simple animation made with css when render app
- I made infinite loop animation for apps logo
- I use animejs library to make animation while fetch data
- I use animejs library to make animation of card note when update note 
- I use animejs library to make animation of card note dragable 
<br>
<br>
<br>






###### <center> @copyright Miftahurrohman FC-38</center>

